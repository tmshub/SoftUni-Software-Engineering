﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.WildFarm.Models.Foods
{
    class Fruit : Food
    {
        protected Fruit(int quantity)
            : base(quantity)
        {

        }
    }
}
