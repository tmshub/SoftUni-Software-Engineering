﻿using _04.WildFarm.Models;
using System;

namespace _04.WildFarm
{
   public class Program
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
